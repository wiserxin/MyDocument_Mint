# Brief
 MIT-OSE 6.828 2011 Fall Labs for studying
 This repository was added to MIT-OSE-Labs as a submodule.

# Change log
* Lab1 complete: merge from MIT-OSE-Labs:/lab directory
