// implement fork from user space

#include "lib.h"
#include <mmu.h>
#include <env.h>

/* ----------------- help functions ---------------- */

/* Overview:
 * 	Copy `len` bytes from `src` to `dst`.
 *
 * Pre-Condition:
 * 	`src` and `dst` can't be NULL. Also, the `src` area 
 * 	 shouldn't overlap the `dest`, otherwise the behavior of this 
 * 	 function is undefined.
 */
void user_bcopy(const void *src, void *dst, size_t len)
{
	void *max;

	//	writef("~~~~~~~~~~~~~~~~ src:%x dst:%x len:%x\n",(int)src,(int)dst,len);
	max = dst + len;

	// copy machine words while possible
	if (((int)src % 4 == 0) && ((int)dst % 4 == 0)) {
		while (dst + 3 < max) {
			*(int *)dst = *(int *)src;
			dst += 4;
			src += 4;
		}
	}

	// finish remaining 0-3 bytes
	while (dst < max) {
		*(char *)dst = *(char *)src;
		dst += 1;
		src += 1;
	}

	//for(;;);
}

/* Overview:
 * 	Sets the first n bytes of the block of memory 
 * pointed by `v` to zero.
 * 
 * Pre-Condition:
 * 	`v` must be valid.
 *
 * Post-Condition:
 * 	the content of the space(from `v` to `v`+ n) 
 * will be set to zero.
 */
void user_bzero(void *v, u_int n)
{
	char *p;
	int m;

	p = v;
	m = n;

	while (--m >= 0) {
		*p++ = 0;
	}
}
/*------------------------------------------
--------------------*/

/* Overview:
 * 	Custom page fault handler - if faulting page is copy-on-write,
 * map in our own private writable copy.
 * 
 * Pre-Condition:
 * 	`va` is the address which leads to a TLBS exception.
 *
 * Post-Condition:
 *  Launch a user_panic if `va` is not a copy-on-write page.
 * Otherwise, this handler should map a private writable copy of 
 * the faulting page at correct address.
 */
static void
pgfault(u_int va)
{
	u_int tmp;
		writef("fork.c:pgfault():\t va:%x\n",va);
    va = ROUNDDOWN(va,BY2PG);
    tmp = (*vpt)[VPN(va)];

    if ((tmp & (0|PTE_COW)) ==0)
        syscall_panic("NOT COW IN pgfault...");

    tmp = syscall_getenvid();
    //this addr may be not good enough ???
    syscall_mem_alloc(tmp,USTACKTOP,PTE_V|PTE_R);
    user_bcopy((void*)va,USTACKTOP,BY2PG);
    syscall_mem_map(tmp,USTACKTOP,tmp,va,PTE_V|PTE_R);

    syscall_mem_unmap(tmp,USTACKTOP);



    //map the new page at a temporary place

	//copy the content
	
    //map the page on the appropriate place
	
    //unmap the temporary place
	
}

static void
my_pgfault_for_stack(u_int dstid)
{
 
    void * va = USTACKTOP-BY2PG;

    u_int srcid = syscall_getenvid();
    //this addr may be not good enough ???
    syscall_mem_alloc(srcid,USTACKTOP,PTE_V|PTE_R);
    user_bcopy((void*)va,USTACKTOP,BY2PG);
    syscall_mem_map(srcid,USTACKTOP,dstid,va,PTE_V|PTE_R);

    syscall_mem_unmap(srcid,USTACKTOP);



    //map the new page at a temporary place

	//copy the content
	
    //map the page on the appropriate place
	
    //unmap the temporary place
	
}



/* Overview:
 * 	Map our virtual page `pn` (address pn*BY2PG) into the target `envid`
 * at the same virtual address. 
 *
 * Post-Condition:
 *  if the page is writable or copy-on-write, the new mapping must be 
 * created copy on write and then our mapping must be marked 
 * copy on write as well. In another word, both of the new mapping and
 * our mapping should be copy-on-write if the page is writable or 
 * copy-on-write.
 * 
 * Hint:
 * 	PTE_LIBRARY indicates that the page is shared between processes.
 * A page with PTE_LIBRARY may have PTE_R at the same time. You
 * should process it correctly.
 */
static void
duppage(u_int envid, u_int pn)
{
	/* Note:
	 *  I am afraid I have some bad news for you. There is a ridiculous, 
	 * annoying and awful bug here. I could find another more adjectives 
	 * to qualify it, but you have to reproduce it to understand 
	 * how disturbing it is.
	 * 	To reproduce this bug, you should follow the steps bellow:
	 * 	1. uncomment the statement "writef("");" bellow.
	 * 	2. make clean && make
	 * 	3. lauch Gxemul and check the result.
	 * 	4. you can add serveral `writef("");` and repeat step2~3.
	 * 	Then, you will find that additional `writef("");` may lead to
	 * a kernel panic. Interestingly, some students, who faced a strange 
	 * kernel panic problem, found that adding a `writef("");` could solve
	 * the problem. 
	 *  Unfortunately, we cannot find the code which leads to this bug,
	 * although we have debugged it for serveral weeks. If you face this
	 * bug, we would like to say "Good luck. God bless."
	 */

	
  writef("");
    u_int addr;
	u_int perm;
    
    int r = 0;
    int srcid = syscall_getenvid();    
    perm = ((*vpt)[pn]) & 0xfff;
    
    if (pn==0x7f3fd)    //USTACKTOP-BY2PG
    {
        perm=perm|PTE_COW;
        /*
        if((r=syscall_mem_map(srcid, pn * BY2PG, envid, pn * BY2PG, perm)) < 0)
        {
            //sys_mem_map
            writef("error code is %d ...\n",r);
            user_panic("Error in duppage No.0");
        }
        
       //my_pgfault_for_stack(envid);
        */
        return;

    }
    else if( (perm&PTE_R)!=0)  // || (perm&PTE_COW)!=0
    {
        if(perm & PTE_LIBRARY) 
            perm = perm|PTE_V|PTE_R;
        else 
            perm = perm |PTE_V|PTE_R|PTE_COW;

        if((r=syscall_mem_map(srcid, pn * BY2PG, envid, pn * BY2PG, perm)) < 0)
        {
            //sys_mem_map
            writef("error code is %d ...\n",r);
            user_panic("Error in duppage No.1");
        }

        if((r=syscall_mem_map(srcid, pn * BY2PG, srcid, pn * BY2PG, perm)) < 0)
            user_panic("Error in duppage No.2");
    }
    else 
    {
        if((r=syscall_mem_map(srcid,pn*BY2PG,envid,pn*BY2PG,perm))<0)
            user_panic("Error ic duppage NO.3");
    }
    
	//	user_panic("duppage not implemented");
}

/* Overview:
 * 	User-level fork. Create a child and then copy our address space
 * and page fault handler setup to the child.
 *
 * Hint: use vpd, vpt, and duppage.
 *      vpd is virtual page dictionary 
 * and  vpt is virtual page table
 *                          ----wiserxin
 * Hint: remember to fix "env" in the child process!
 * Note: `set_pgfault_handler`(user/pgfault.c) is different from 
 *       `syscall_set_pgfault_handler`. 
 */
extern void __asm_pgfault_handler(void);
int
fork(void)
{
	// Your code here.
	u_int newenvid;
	extern struct Env *envs;
	extern struct Env *env;
	int pn;
    

    //The parent installs pgfault using set_pgfault_handler
    set_pgfault_handler(pgfault);
    newenvid = syscall_env_alloc();
//    sys_env_alloc
    if(newenvid<0)return newenvid;

    if(newenvid>0)    //父进程执行
    {
//        writef("all pn is 0x%x\n",USTACKTOP/BY2PG);
        for(pn=0;pn<(USTACKTOP/BY2PG);pn++)
        {
            if(((*vpd)[pn/PTE2PT]) != 0 && ((*vpt)[pn]) != 0)
            {
//                writef("pn is 0x%x , perm is 0x%x\n",pn,((*vpt)[pn]) & 0xfff);
                duppage(newenvid,pn);
                //writef("in to **********\n\n\n\n");
            }
        }
        
        

//        writef("out of \n");
        //writef("in father env is 0x%x\n",env->env_id);
        syscall_mem_alloc(newenvid,UXSTACKTOP-BY2PG,PTE_V|PTE_R);
        syscall_set_pgfault_handler(newenvid,__asm_pgfault_handler,UXSTACKTOP);
//        sys_set_pgfault_handler
        syscall_set_env_status(newenvid,ENV_RUNNABLE);
    }
    else    //子进程执行
    {
        //writef("in son env is 0x%x\n",envs[1].env_id);
        //set_pgfault_handler(pgfault);
        env = &envs[ENVX(syscall_getenvid())]; // use syscall_getenvid ???
        //writef("env is 0x%x\n",env);
        //env = &envs[0]; // use syscall_getenvid ???
        return 0;
    }

//writef("env id is %d \n",syscall_getenvid());
//syscall_panic("1********\n");

	//alloc a new alloc


	return newenvid;
}

// Challenge!
int
sfork(void)
{
	user_panic("sfork not implemented");
	return -E_INVAL;
}
