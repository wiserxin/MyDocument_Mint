#include "lib.h"

void umain()
{
	while (1) {
		writef("IDLE!");
	}
}
