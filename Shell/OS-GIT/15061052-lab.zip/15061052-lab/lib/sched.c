#include <env.h>
#include <pmap.h>
#include <printf.h>

/* Overview:
 *  Implement simple round-robin scheduling.
 *  Search through 'envs' for a runnable environment ,
 *  in circular fashion statrting after the previously running env,
 *  and switch to the first such environment found.
 *
 * Hints:
 *  The variable which is for counting should be defined as 'static'.
 */
void sched_yield(void)
{	
	static int i=0;
	for(;;){
	  if(i==NENV) i=0;
	 // printf("yield\n");
	  if(envs[i].env_status==ENV_RUNNABLE){
		env_run(&envs[i++]);
		break;
		}
	  //printf("yield2\n");
	  i++;
	}
}
